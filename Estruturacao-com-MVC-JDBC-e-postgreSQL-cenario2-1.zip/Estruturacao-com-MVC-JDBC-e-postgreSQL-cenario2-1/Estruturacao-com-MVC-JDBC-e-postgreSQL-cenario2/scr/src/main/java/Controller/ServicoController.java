package Controller;

import Model.Cliente;
import Model.Servico;
import Model.Veiculo;
import Service.ClienteService;
import Service.ServicoService;
import Service.VeiculoService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ServicoController {

    ServicoService servicoService = new ServicoService();

    public void cadastrar(Cliente cliente, Veiculo veiculo, BigDecimal valor, String descricao, boolean isConcluida) throws SQLException {
        try{
            Servico servico = new Servico(veiculo,cliente , valor, descricao, isConcluida);
            Servico salvo = servicoService.Salvar(servico);
            System.out.println("Serviço cadastrado com sucesso! " + salvo);

        }catch (SQLException e){
            System.out.println("Erro no banco: " + e.getMessage());
        }catch(IllegalArgumentException e){
            System.out.println("Valor inválido: " + e.getMessage());
        }
    }

    public List<Servico> listarPorCliente(long id_cliente) throws SQLException {
        try{
            return servicoService.buscarPorIdCliente(id_cliente);

        }catch (SQLException e){
            System.out.println("Erro no banco: " + e.getMessage());
            return List.of();
        }catch(IllegalArgumentException e){
            System.out.println("Valor inválido: " + e.getMessage());
            return List.of();
        }
    }

    public void update(Servico servico) throws SQLException {
        try{
            servicoService.update(servico);
        }catch (SQLException e){
            System.out.println("Erro no banco: " + e.getMessage());
        }
    }

    public void deletar(long id_consulta) throws SQLException {
        try{
            servicoService.delete(id_consulta);
        }catch (SQLException e){
            System.out.println("Erro no banco: " + e.getMessage());
        }
    }

    public void listarTodos() {
        try {
            List<Servico> servicos = servicoService.listarTodos();

            if (servicos.isEmpty()) {
                System.out.println("Nenhum serviço encontrado.");
            } else {
                System.out.println("\n=== LISTA DE Serviços ===");
                for (Servico a : servicos) {
                    System.out.printf("ID: %d | Veiculo: %d | Cliente: %d, | Valor:%f |Descrição:%s | Concluido:%b\n",
                            a.getId(), a.getVeiculo().getId(), a.getCliente().getId(), a.getValor(), a.getDescricao(), a._isConcluida());
                }
            }
        } catch(SQLException e) {
            System.out.println("Erro no banco: " + e.getMessage());
        }
    }



}
